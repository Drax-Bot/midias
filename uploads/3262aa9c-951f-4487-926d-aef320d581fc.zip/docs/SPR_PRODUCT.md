# SPR Privado para Zapo

Produto digital de Rei Ayanami, com assistência de desenvolvimento CodeX AI.

## Conteúdo

- Relay individual dentro do grupo, sem envio por PV.
- Modos individual, administrativo e exclusivo do dono.
- Personalização por nome, usuário e avatar.
- Fallback vazio corrigido para iOS e fanout pelo dispositivo principal quando não existem companions.
- Compatibilidade validada em iOS, Android e WhatsApp Web/Desktop.

## Licença

Licença pessoal para uso em um único bot Zapo. É proibido revender, redistribuir, publicar ou compartilhar este pacote. O comprador deve adaptar imports e integração ao dispatcher da própria base. Sessões, credenciais, bancos e suporte ao repositório completo não fazem parte do ZIP.

